/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/36.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-36/framework.aidl -o/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/release/aidl -d/tmp/aidl9167857689457834627.d /home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl/io/github/daniele21/localllm/transport/binder/contract/IClientLifecycle.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package io.github.daniele21.localllm.transport.binder.contract;
public interface IClientLifecycle extends android.os.IInterface
{
  /** Default implementation for IClientLifecycle. */
  public static class Default implements io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle
  {
    @Override public void onHostDisconnecting() throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle interface,
     * generating a proxy if needed.
     */
    public static io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle))) {
        return ((io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle)iin);
      }
      return new io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onHostDisconnecting:
        {
          this.onHostDisconnecting();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onHostDisconnecting() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onHostDisconnecting, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onHostDisconnecting = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle";
  public void onHostDisconnecting() throws android.os.RemoteException;
}
