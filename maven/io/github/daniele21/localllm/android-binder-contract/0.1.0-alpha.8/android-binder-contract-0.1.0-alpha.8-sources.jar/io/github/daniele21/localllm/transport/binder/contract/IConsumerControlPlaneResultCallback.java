/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/36.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-36/framework.aidl -o/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/release/aidl -d/tmp/aidl10003146957039115714.d /home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl/io/github/daniele21/localllm/transport/binder/contract/IConsumerControlPlaneResultCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package io.github.daniele21.localllm.transport.binder.contract;
public interface IConsumerControlPlaneResultCallback extends android.os.IInterface
{
  /** Default implementation for IConsumerControlPlaneResultCallback. */
  public static class Default implements io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback
  {
    @Override public void onResult(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneResultParcel result) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback interface,
     * generating a proxy if needed.
     */
    public static io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback))) {
        return ((io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback)iin);
      }
      return new io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onResult:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneResultParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneResultParcel.CREATOR);
          this.onResult(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onResult(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneResultParcel result) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, result, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onResult, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback";
  public void onResult(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneResultParcel result) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
