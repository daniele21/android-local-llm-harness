/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/36.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-36/framework.aidl -o/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/release/aidl -d/tmp/aidl10295101179492433470.d /home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl/io/github/daniele21/localllm/transport/binder/contract/IConsumerLocalLlmService.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package io.github.daniele21.localllm.transport.binder.contract;
public interface IConsumerLocalLlmService extends android.os.IInterface
{
  /** Default implementation for IConsumerLocalLlmService. */
  public static class Default implements io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService
  {
    @Override public void capabilities(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void prepare(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void openSession(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void generate(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException
    {
    }
    @Override public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException
    {
    }
    @Override public void discoverUseCases(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void discoverPresets(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void activate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void deactivate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
    {
    }
    // Appended in protocol minor 3 so existing transaction IDs remain stable.
    @Override public void generateV2(io.github.daniele21.localllm.transport.binder.contract.ConsumerGenerationRequestV2Parcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService interface,
     * generating a proxy if needed.
     */
    public static io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService))) {
        return ((io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService)iin);
      }
      return new io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_capabilities:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback.Stub.asInterface(data.readStrongBinder());
          this.capabilities(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_prepare:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback.Stub.asInterface(data.readStrongBinder());
          this.prepare(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_openSession:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback.Stub.asInterface(data.readStrongBinder());
          this.openSession(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_generate:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback.Stub.asInterface(data.readStrongBinder());
          this.generate(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_cancel:
        {
          io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel.CREATOR);
          this.cancel(_arg0);
          break;
        }
        case TRANSACTION_closeSession:
        {
          io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel.CREATOR);
          this.closeSession(_arg0);
          break;
        }
        case TRANSACTION_discoverUseCases:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback.Stub.asInterface(data.readStrongBinder());
          this.discoverUseCases(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_discoverPresets:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback.Stub.asInterface(data.readStrongBinder());
          this.discoverPresets(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_activate:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback.Stub.asInterface(data.readStrongBinder());
          this.activate(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_deactivate:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback.Stub.asInterface(data.readStrongBinder());
          this.deactivate(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_generateV2:
        {
          io.github.daniele21.localllm.transport.binder.contract.ConsumerGenerationRequestV2Parcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ConsumerGenerationRequestV2Parcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback.Stub.asInterface(data.readStrongBinder());
          this.generateV2(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void capabilities(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_capabilities, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void prepare(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_prepare, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void openSession(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_openSession, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void generate(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_generate, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancel, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_closeSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void discoverUseCases(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_discoverUseCases, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void discoverPresets(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_discoverPresets, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void activate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_activate, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void deactivate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_deactivate, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      // Appended in protocol minor 3 so existing transaction IDs remain stable.
      @Override public void generateV2(io.github.daniele21.localllm.transport.binder.contract.ConsumerGenerationRequestV2Parcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_generateV2, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_capabilities = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_prepare = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_openSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_generate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_cancel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_closeSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_discoverUseCases = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_discoverPresets = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_activate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_deactivate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_generateV2 = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService";
  public void capabilities(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException;
  public void prepare(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException;
  public void openSession(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerResultCallback callback) throws android.os.RemoteException;
  public void generate(io.github.daniele21.localllm.transport.binder.contract.ConsumerRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException;
  public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException;
  public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException;
  public void discoverUseCases(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException;
  public void discoverPresets(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException;
  public void activate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException;
  public void deactivate(io.github.daniele21.localllm.transport.binder.contract.ConsumerControlPlaneRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerControlPlaneResultCallback callback) throws android.os.RemoteException;
  // Appended in protocol minor 3 so existing transaction IDs remain stable.
  public void generateV2(io.github.daniele21.localllm.transport.binder.contract.ConsumerGenerationRequestV2Parcel request, io.github.daniele21.localllm.transport.binder.contract.IConsumerGenerationCallback callback) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
