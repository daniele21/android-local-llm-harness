/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/36.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-36/framework.aidl -o/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl -I/home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/release/aidl -d/tmp/aidl5788911719509067182.d /home/runner/work/android-local-llm-harness/android-local-llm-harness/transports/android-binder-contract/src/main/aidl/io/github/daniele21/localllm/transport/binder/contract/ILocalLlmService.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package io.github.daniele21.localllm.transport.binder.contract;
public interface ILocalLlmService extends android.os.IInterface
{
  /** Default implementation for ILocalLlmService. */
  public static class Default implements io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService
  {
    @Override public io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel getProtocolInfo() throws android.os.RemoteException
    {
      return null;
    }
    @Override public void registerClient(io.github.daniele21.localllm.transport.binder.contract.ClientHelloParcel hello, io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle lifecycle, io.github.daniele21.localllm.transport.binder.contract.IRegistrationCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void prepare(io.github.daniele21.localllm.transport.binder.contract.PrepareRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IPrepareCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void openSession(io.github.daniele21.localllm.transport.binder.contract.OpenSessionRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.ISessionCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void generate(io.github.daniele21.localllm.transport.binder.contract.GenerationRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IGenerationCallback callback) throws android.os.RemoteException
    {
    }
    @Override public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException
    {
    }
    @Override public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException
    {
    }
    @Override public void unregisterClient(io.github.daniele21.localllm.transport.binder.contract.ClientTokenParcel clientToken) throws android.os.RemoteException
    {
    }
    @Override public io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService getConsumerApi() throws android.os.RemoteException
    {
      return null;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService interface,
     * generating a proxy if needed.
     */
    public static io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService))) {
        return ((io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService)iin);
      }
      return new io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getProtocolInfo:
        {
          io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel _result = this.getProtocolInfo();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_registerClient:
        {
          io.github.daniele21.localllm.transport.binder.contract.ClientHelloParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ClientHelloParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle.Stub.asInterface(data.readStrongBinder());
          io.github.daniele21.localllm.transport.binder.contract.IRegistrationCallback _arg2;
          _arg2 = io.github.daniele21.localllm.transport.binder.contract.IRegistrationCallback.Stub.asInterface(data.readStrongBinder());
          this.registerClient(_arg0, _arg1, _arg2);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_prepare:
        {
          io.github.daniele21.localllm.transport.binder.contract.PrepareRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.PrepareRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IPrepareCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IPrepareCallback.Stub.asInterface(data.readStrongBinder());
          this.prepare(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_openSession:
        {
          io.github.daniele21.localllm.transport.binder.contract.OpenSessionRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.OpenSessionRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.ISessionCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.ISessionCallback.Stub.asInterface(data.readStrongBinder());
          this.openSession(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_generate:
        {
          io.github.daniele21.localllm.transport.binder.contract.GenerationRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.GenerationRequestParcel.CREATOR);
          io.github.daniele21.localllm.transport.binder.contract.IGenerationCallback _arg1;
          _arg1 = io.github.daniele21.localllm.transport.binder.contract.IGenerationCallback.Stub.asInterface(data.readStrongBinder());
          this.generate(_arg0, _arg1);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_cancel:
        {
          io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel.CREATOR);
          this.cancel(_arg0);
          break;
        }
        case TRANSACTION_closeSession:
        {
          io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel.CREATOR);
          this.closeSession(_arg0);
          break;
        }
        case TRANSACTION_unregisterClient:
        {
          io.github.daniele21.localllm.transport.binder.contract.ClientTokenParcel _arg0;
          _arg0 = _Parcel.readTypedObject(data, io.github.daniele21.localllm.transport.binder.contract.ClientTokenParcel.CREATOR);
          this.unregisterClient(_arg0);
          break;
        }
        case TRANSACTION_getConsumerApi:
        {
          io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService _result = this.getConsumerApi();
          reply.writeNoException();
          reply.writeStrongInterface(_result);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel getProtocolInfo() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getProtocolInfo, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void registerClient(io.github.daniele21.localllm.transport.binder.contract.ClientHelloParcel hello, io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle lifecycle, io.github.daniele21.localllm.transport.binder.contract.IRegistrationCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, hello, 0);
          _data.writeStrongInterface(lifecycle);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerClient, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void prepare(io.github.daniele21.localllm.transport.binder.contract.PrepareRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IPrepareCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_prepare, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void openSession(io.github.daniele21.localllm.transport.binder.contract.OpenSessionRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.ISessionCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_openSession, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void generate(io.github.daniele21.localllm.transport.binder.contract.GenerationRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IGenerationCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_generate, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_cancel, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, request, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_closeSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void unregisterClient(io.github.daniele21.localllm.transport.binder.contract.ClientTokenParcel clientToken) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, clientToken, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterClient, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService getConsumerApi() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getConsumerApi, _data, _reply, 0);
          _reply.readException();
          _result = io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService.Stub.asInterface(_reply.readStrongBinder());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_getProtocolInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_registerClient = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_prepare = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_openSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_generate = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_cancel = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_closeSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_unregisterClient = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_getConsumerApi = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "io.github.daniele21.localllm.transport.binder.contract.ILocalLlmService";
  public io.github.daniele21.localllm.transport.binder.contract.ProtocolInfoParcel getProtocolInfo() throws android.os.RemoteException;
  public void registerClient(io.github.daniele21.localllm.transport.binder.contract.ClientHelloParcel hello, io.github.daniele21.localllm.transport.binder.contract.IClientLifecycle lifecycle, io.github.daniele21.localllm.transport.binder.contract.IRegistrationCallback callback) throws android.os.RemoteException;
  public void prepare(io.github.daniele21.localllm.transport.binder.contract.PrepareRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IPrepareCallback callback) throws android.os.RemoteException;
  public void openSession(io.github.daniele21.localllm.transport.binder.contract.OpenSessionRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.ISessionCallback callback) throws android.os.RemoteException;
  public void generate(io.github.daniele21.localllm.transport.binder.contract.GenerationRequestParcel request, io.github.daniele21.localllm.transport.binder.contract.IGenerationCallback callback) throws android.os.RemoteException;
  public void cancel(io.github.daniele21.localllm.transport.binder.contract.CancelRequestParcel request) throws android.os.RemoteException;
  public void closeSession(io.github.daniele21.localllm.transport.binder.contract.CloseSessionRequestParcel request) throws android.os.RemoteException;
  public void unregisterClient(io.github.daniele21.localllm.transport.binder.contract.ClientTokenParcel clientToken) throws android.os.RemoteException;
  public io.github.daniele21.localllm.transport.binder.contract.IConsumerLocalLlmService getConsumerApi() throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
